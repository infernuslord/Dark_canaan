/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/_editgeo.h,v 1.2 2000/01/29 12:41:55 adurant Exp $
#pragma once

#ifndef ___EDITGEO_H
#define ___EDITGEO_H

EXTERN void editgeom_init(void);
EXTERN void editgeom_term(void);


#endif // ___EDITGEO_H
