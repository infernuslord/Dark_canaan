/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

#pragma once
DEFINE_LG_GUID(IID_IGameStrings, 0x194);

