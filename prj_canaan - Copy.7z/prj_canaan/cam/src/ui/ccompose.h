/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/ui/ccompose.h,v 1.1 1998/04/02 14:55:53 mahk Exp $
#pragma once  
#ifndef __CCOMPOSE_H
#define __CCOMPOSE_H

//
// Cursor composition function, takes a cursor draw command (see UI)
//
EXTERN void compose_cursor(int cmd);


#endif // __CCOMPOSE_H
