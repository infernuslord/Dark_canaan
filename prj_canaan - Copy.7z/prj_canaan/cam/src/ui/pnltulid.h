/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

//
// Panel tool IIDs 
//
#pragma once

DEFINE_LG_GUID(LOOPMODE_StaticImagePanel, 0x10c);
DEFINE_LG_GUID(LOOPID_MovieClient   , 0x10f);
DEFINE_LG_GUID(LOOPMODE_Movie, 0x110);
