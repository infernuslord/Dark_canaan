/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/ui/panlguid.h,v 1.2 2000/01/31 10:05:00 adurant Exp $
#pragma once


//
// Panel GUIDs
//

DEFINE_LG_GUID(LOOPID_Panel, 0x10a);
DEFINE_LG_GUID(IID_IPanelMode, 0x10b);
