/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/airecovr.cpp,v 1.1 1998/10/03 11:24:03 TOML Exp $
//
//
//
