/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aidodgep.h,v 1.2 2000/01/29 12:45:16 adurant Exp $
//
//
//
#pragma once

#ifndef __AIDODGEP_H
#define __AIDODGEP_H

#endif /* !__AIDODGEP_H */
