/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aie3bhv.cpp,v 1.4 1998/08/16 13:01:08 TOML Exp $
//
//
//
