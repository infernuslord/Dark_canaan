/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aiactfrb.cpp,v 1.1 1998/04/26 18:12:32 TOML Exp $
//
//
//

#include <aiactfrb.h>

// Must be last header
#include <dbmem.h>

