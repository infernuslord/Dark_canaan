/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aidbdraw.h,v 1.4 2000/01/29 12:45:13 adurant Exp $
//
//
//
#pragma once

#ifndef __AIDBDRAW_H
#define __AIDBDRAW_H

#include <aipath.h>
#include <aimovsug.h>
#include <matrixc.h>
#include <aiapiiai.h>

EXTERN void AIPathFindDrawPath(cAIPath &path);

#endif /* !__AIDBDRAW_H */
