/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aicmds.h,v 1.2 2000/01/29 12:45:08 adurant Exp $
//
//
//
#pragma once

#ifndef __AICMDS_H
#define __AICMDS_H

void AIInstallCommands();

#endif /* !__AICMDS_H */
