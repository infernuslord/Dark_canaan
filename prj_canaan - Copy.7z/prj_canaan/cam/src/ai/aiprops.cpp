/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aiprops.cpp,v 1.22 1998/06/09 20:02:29 TOML Exp $
//

#include <aiprops.h>

// Must be last header
#include <dbmem.h>

