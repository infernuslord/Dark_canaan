/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

///////////////////////////////////////////////////////////////////////////////
// $Header: r:/t2repos/thief2/src/ai/aiguard.h,v 1.2 2000/01/29 12:45:23 adurant Exp $
//
//
//
#pragma once

#ifndef __AIGUARD_H
#define __AIGUARD_H

#endif /* !__AIGUARD_H */
