/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/persloop.h,v 1.3 2000/01/29 12:41:41 adurant Exp $
#pragma once
#ifndef __PERSLOOP_H
#define __PERSLOOP_H

DEFINE_LG_GUID(LOOPID_People, 0x34);

EXTERN struct sLoopClientDesc PersonLoopClientDesc;

//
// KEEP THIS FILE RELATIVELY CLEAR OF JUNK!  DO NOT PUT YOUR SYSTEM'S API HERE! 
// DO NOT INCLUDE OTHER HEADER FILES FROM THIS FILE!
//

 
#endif // __PERSLOOP_H
