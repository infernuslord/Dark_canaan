/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

#pragma once
DEFINE_LG_GUID(IID_IPeriodicPropagator, 0x1b5);
