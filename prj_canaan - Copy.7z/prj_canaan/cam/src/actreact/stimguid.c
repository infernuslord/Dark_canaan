/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/actreact/stimguid.c,v 1.2 2000/02/19 12:17:17 toml Exp $

#include <initguid.h>
#include <stimguid.h>
#include <memall.h>
#include <dbmem.h>   // must be last header! 

//
// INCLUDE NO OTHER FILES!
//

//
// (This is a guid instantiation file)
//
