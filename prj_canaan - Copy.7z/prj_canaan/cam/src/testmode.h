/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/testmode.h,v 1.2 2000/01/29 12:41:48 adurant Exp $
#pragma once
#ifndef __TESTMODE_H
#define __TESTMODE_H



DEFINE_LG_GUID(LOOPID_DebugMode, 0x20);

EXTERN struct sLoopModeDesc TestLoopMode;
   
#endif // __TESTMODE_H
