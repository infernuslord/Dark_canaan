/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/testloop.h,v 1.3 2000/01/29 12:41:47 adurant Exp $
#pragma once

#ifndef __TESTLOOP_H
#define __TESTLOOP_H

DEFINE_LG_GUID(LOOPID_Test, 0x21);
EXTERN struct sLoopClientDesc TestLoopClientDesc;

#endif // __TESTLOOP_H
