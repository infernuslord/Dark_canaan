/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/dialogs.h,v 1.3 2000/01/29 12:41:09 adurant Exp $
#pragma once

#ifndef __DIALOGS_H
#define __DIALOGS_H

#define IDD_ADDLINKDIALOG               101
#define IDC_FLAVORCOMBO                 1000
#define IDC_FROMEDIT                    1001
#define IDC_TOEDIT                      1002
#define IDC_DATAEDIT                    1003
#define IDC_NAMEEDIT                    1004
#define IDC_STATIC                      -1

#endif // __DIALOGS_H
