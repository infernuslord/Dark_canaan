/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/sim/objloop.h,v 1.3 2000/01/29 13:41:21 adurant Exp $
#pragma once
#ifndef __OBJLOOP_H
#define __OBJLOOP_H




DEFINE_LG_GUID(LOOPID_ObjSys, 0x36);
EXTERN struct sLoopClientDesc ObjSysLoopClientDesc;

//
// KEEP THIS FILE RELATIVELY CLEAR OF JUNK!  DO NOT PUT YOUR SYSTEM'S API HERE! 
// DO NOT INCLUDE OTHER HEADER FILES FROM THIS FILE!
//

 
#endif // __OBJLOOP_H
