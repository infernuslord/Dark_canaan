/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/sim/ghostshk.h,v 1.1 1999/08/05 18:15:23 Justin Exp $
//

#ifndef __GHOSTSHK_H
#pragma once
#define __GHOSTSHK_H

EXTERN void ShockGhostInit(void);

#endif  // __GHOSTSHK_H
