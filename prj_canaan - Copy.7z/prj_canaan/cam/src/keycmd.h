/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// $Header: r:/t2repos/thief2/src/keycmd.h,v 1.4 2000/01/29 12:41:33 adurant Exp $
#pragma once

//game specific input binding variable/commands

#include <inpbnd_i.h>

EXTERN IInputBinder *g_pInputBinder;
EXTERN IB_var g_pInputBinderVars[];
