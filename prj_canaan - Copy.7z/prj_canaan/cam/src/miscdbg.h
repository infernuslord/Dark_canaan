/*
@Copyright Looking Glass Studios, Inc.
1996,1997,1998,1999,2000 Unpublished Work.
*/

// miscdbg.h
//
// Stupid debug stuff
//
// $Header: r:/t2repos/thief2/src/miscdbg.h,v 1.2 2000/01/29 12:41:38 adurant Exp $
#pragma once

void DfanTest (void);
